package chess;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		boolean winner = false;
		
		ChessBoard chess = new ChessBoard();
		
		Scanner scan = new Scanner(System.in);
		
		
		
		while(!winner) {
			
			boolean white = true;
			boolean black = true;
			
			System.out.println();
			chess.danger1();
			System.out.println();
			chess.danger2();
			System.out.println();
			
			chess.printBoard();
			
			while(white) {
				
				//get which piece to move
				System.out.println("\nIt's White player's turn to move\n");
				System.out.println("What piece would you like to move?");
				
				String from = scan.nextLine();
				
				//get where to move piece
				System.out.println("Where would you like to move it?");
				String to = scan.nextLine();
				
				white = move(from, to, chess);
				
			}
			
			if(chess.check()) {
				
				if(chess.checkmate()) {
					
					winner = true;	
					
					
				}
				
			}
			
			if(!winner) {
				
				System.out.println();
				chess.danger1();
				System.out.println();
				chess.danger2();
				System.out.println();
				
				chess.printBoard();
				
				while(black) {
					
					//get which piece to move
					System.out.println("\nIt's Black player's turn to move\n");
					System.out.println("What piece would you like to move?");
					
					String from = scan.nextLine();
					
					//get where to move piece
					System.out.println("Where would you like to move it?");
					String to = scan.nextLine();
					
					black = move(from, to, chess);
					
				}
				
			}
			
			if(chess.check()) {
				
				chess.checkmate();
				
				winner = true;	
				
			}
			
		}
		
		scan.close();
		
	}
	
	public static boolean move(String from, String to, ChessBoard chess) {
		
		int start=0,end=0;
		
		try{
			
			start = ChessBoard.coordGrab(from);
			end = ChessBoard.coordGrab(to);
			
			if(chess.capture(start/10, start%10, end/10, end%10)) {
				
				return false;
				
				
			} else {
				
				chess.printBoard();
				
				System.out.println("\nYou can't do that move");
				
			}
			
		}
		
		catch(RuntimeException e) {
			
			
			
		}
		
		return true;
		
	}
	
}
